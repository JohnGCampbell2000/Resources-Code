import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client {

	public static void main(String[] args) throws Exception {
		//Asks client for IP address, and scans IP input
		System.out.println("IP: ");
		Scanner ipScanner = new Scanner(System.in);
		String ip = ipScanner.nextLine();
		Socket clientSocket = new Socket(ip, 13001);
		
		int yes = 1;
		
		//Scanners for server message and client input
		Scanner inFromServer = new Scanner(clientSocket.getInputStream());
		Scanner in = new Scanner(System.in);
		
		while(true) {
			System.out.println("Input a number: "); //user input
			String guess = in.nextLine();
			PrintWriter outToServer = new PrintWriter(clientSocket.getOutputStream(), true); //object used to encode messages to server
			outToServer.println(guess); //send to server
			
			String answer = inFromServer.nextLine(); //answer from server is received
			
			System.out.println(answer); //low, high, or correct
			
			//if the answer is correct, ask the user to play again. If yes, let server know. Else, break
			if(answer.toString().equals("correct")) {
				System.out.println("Play again? y or n");
				String cont = in.nextLine();
				if(cont.equals("n")) {
					break;
				}
				else if(cont.equals("y")) {
					outToServer.println(yes); //sends 1 to server if user inputs 'y'
					continue;
				}
				
			}
		}
	}

}