from socket import *
import random
serverPort = 13001
welcomeSocket = socket (AF_INET, SOCK_STREAM)
welcomeSocket.bind(('', serverPort))
welcomeSocket.listen(1)

randNumber = random.randint(1, 1000) #generates random number to be guessed
print(randNumber)
high = "high"
low = "low"
correct = "correct"
connectionSocket, addr = welcomeSocket.accept()  #set up socket to connect to client
while True:
    number = connectionSocket.recv(4096) #receive number guess from client
    number = int(number) #convert from bytes to int

    #if the guess is less than the random number, send back low
    #if the guess is higher than the random number, send back high
    #if the guess is the same as the number, send back correct
    if number < randNumber:
        higher = low.encode('utf-8')
        connectionSocket.send(higher + '\n'.encode())

    elif number > randNumber:
        lower = high.encode('utf-8')
        connectionSocket.send(lower + '\n'.encode())

    else:
        gameover = correct.encode('utf-8')
        connectionSocket.send(gameover + '\n'.encode())

        letter = connectionSocket.recv(4096).decode() #if game is over, receive a message determining whether to play again
        letter = int(letter) #convert from bytes to int
        if letter == 1: #if the client says yes, the server will receive a 1 and will play again
            randNumber = random.randint(1, 1000) #new random number is generated
            print(randNumber)
            continue
        else:
            connectionSocket.close() #if player responds with no, close sockets and break
            welcomeSocket.close()
            break

